@GetMapping
public ApiResponse<ProfileResponse> getMyProfile(Authentication authentication) {

    System.out.println("===== PROFILE REQUEST =====");
    System.out.println("Authentication: " + authentication);

    try {
        ProfileResponse response =
                profileService.getMyProfile(authentication.getName());

        return ApiResponse.success(response);

    } catch (Exception e) {
        e.printStackTrace();
        throw e;
    }
}